import { resultsContract } from "@monkeytype/contracts/results";
import { initServer } from "@ts-rest/express";
import * as ResultController from "../controllers/result";
import { callController } from "../ts-rest-adapter";

const s = initServer();
export default s.router(resultsContract, {
  get: {
    handler: async (r) => callController(ResultController.getResults)(r),
  },
  getById: {
    handler: async (r) => callController(ResultController.getResultById)(r),
  },
  add: {
    handler: async (r) => callController(ResultController.addResult)(r),
  },
  updateTags: {
    handler: async (r) => callController(ResultController.updateTags)(r),
  },
  getLast: {
    handler: async (r) => callController(ResultController.getLastResult)(r),
  },
});
