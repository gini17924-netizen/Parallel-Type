import {
  ConfigSchema,
  CustomBackgroundSchema,
} from "@monkeytype/schemas/configs";
import { createForm } from "@tanstack/solid-form";
import { createResource, JSXElement, For, Show, Suspense } from "solid-js";

import {
  configMetadata,
  getOptionSearchKeywords,
} from "../../../../config/metadata";
import { setConfig } from "../../../../config/setters";
import { getConfig } from "../../../../config/store";
import { useSavedIndicator } from "../../../../hooks/useSavedIndicator";
import { showNoticeNotification } from "../../../../states/notifications";
import FileStorage from "../../../../utils/file-storage";
import { getOptions } from "../../../../utils/zod";
import { Button } from "../../../common/Button";
import { Fa } from "../../../common/Fa";
import { Separator } from "../../../common/Separator";
import { InputField } from "../../../ui/form/InputField";
import { fromSchema } from "../../../ui/form/utils";
import { SearchableSetting } from "../SearchableSetting";

export function CustomBackground(): JSXElement {
  const savedIndicator = useSavedIndicator();

  const form = createForm(() => ({
    defaultValues: {
      customBackground: getConfig.customBackground,
    },
    onSubmit: ({ value }) => {
      const val = value.customBackground;
      if (val === getConfig.customBackground) return;
      savedIndicator.flash();
      setConfig("customBackground", val);
    },
  }));

  const [hasLocalBackground] = createResource(
    () => FileStorage.track("LocalBackgroundFile"),
    async () => FileStorage.hasFile("LocalBackgroundFile"),
  );

  const readFileAsDataURL = async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  return (
    <SearchableSetting
      key="customBackground"
      title={
        configMetadata.customBackground.displayString ?? "custom background"
      }
      fa={configMetadata.customBackground.fa}
      extraSearchKeywords={getOptionSearchKeywords("customBackgroundSize")}
      description={
        <>
          {configMetadata.customBackground.description}
          <br />
          <div class="mt-2 text-em-xs">
            Note: The local image is stored in your browser&apos;s local storage
            and will not be uploaded to the server. This means that if you clear
            your browser&apos;s local storage or use a different browser, the
            local image will be lost.
          </div>
        </>
      }
      inputs={
        <div class="grid gap-2 self-end">
          {/* latest: a refetch keeps the old value instead of suspending */}
          <Suspense>
            <Show
              when={!hasLocalBackground.latest}
              fallback={
                <Button
                  fa={{ icon: "fa-trash" }}
                  text="remove local background"
                  onClick={() => {
                    void FileStorage.deleteFile("LocalBackgroundFile");
                  }}
                />
              }
            >
              <>
                <input
                  type="file"
                  id="customBackgroundUploadSolid"
                  accept="image/*"
                  class="hidden"
                  onChange={async (e) => {
                    const fileInput = e.target;
                    const file = fileInput.files?.[0];

                    if (!file) {
                      return;
                    }

                    // check type
                    if (!/image\/(jpeg|jpg|png|gif|webp)/.exec(file.type)) {
                      showNoticeNotification("Unsupported image format");
                      fileInput.value = "";
                      return;
                    }

                    const dataUrl = await readFileAsDataURL(file);
                    await FileStorage.storeFile("LocalBackgroundFile", dataUrl);

                    fileInput.value = "";
                  }}
                />
                {/* i cant figure out how to trigger the file input with a Button component */}
                <label
                  // oxlint-disable-next-line react/no-unknown-property
                  for="customBackgroundUploadSolid"
                  class="inline-flex w-full cursor-pointer items-center justify-center gap-[0.5em] rounded border-0 bg-sub-alt p-[0.5em] text-text transition-[color,background,opacity] duration-125 hover:bg-text hover:text-bg"
                >
                  <Fa icon="fa-file-import" fixedWidth />
                  use local image
                </label>
                <Separator text="or" />
              </>
            </Show>
            <Show when={!hasLocalBackground.latest}>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  void form.handleSubmit();
                }}
              >
                <form.Field
                  name="customBackground"
                  validators={{
                    onChange: fromSchema(CustomBackgroundSchema),
                    onBlur: () => {
                      void form.handleSubmit();
                    },
                  }}
                  children={(field) => (
                    <div class="relative">
                      <InputField
                        field={field}
                        placeholder={"image url"}
                        type="text"
                      />
                      <savedIndicator.component />
                    </div>
                  )}
                />
              </form>
            </Show>
          </Suspense>
          <div class="grid grid-cols-[repeat(auto-fit,minmax(4rem,1fr))] gap-2">
            <For each={getOptions(ConfigSchema.shape.customBackgroundSize)}>
              {(option) => {
                const optionMeta = configMetadata.customBackgroundSize
                  .optionsMetadata as Record<
                  string,
                  { displayString?: string }
                >;
                const displayString =
                  optionMeta?.[option]?.displayString ?? option;
                return (
                  <Button
                    active={getConfig.customBackgroundSize === option}
                    onClick={() => {
                      if (getConfig.customBackgroundSize === option) {
                        return;
                      }
                      setConfig("customBackgroundSize", option);
                    }}
                  >
                    {displayString}
                  </Button>
                );
              }}
            </For>
          </div>
        </div>
      }
    />
  );
}
