import { JSXElement, Show } from "solid-js";

import { useCustomThemesLiveQuery } from "../../../collections/custom-themes";
import { setConfig } from "../../../config/setters";
import { Config } from "../../../config/store";
import { showCommandline } from "../../../states/commandline";
import { getThemeIndicator, isAuthenticated } from "../../../states/core";
import { showNoticeNotification } from "../../../states/notifications";
import { Fa } from "../../common/Fa";

export function ThemeIndicator(): JSXElement {
  const themes = useCustomThemesLiveQuery();

  const handleClick = (e: MouseEvent): void => {
    if (e.shiftKey) {
      if (Config.customTheme) {
        setConfig("customTheme", false);
        return;
      }
      if (isAuthenticated() && themes().length < 1) {
        showNoticeNotification("No custom themes!");
        setConfig("customTheme", false);
        return;
      }
      setConfig("customTheme", true);
    } else {
      const subgroup = Config.customTheme ? "customTheme" : "themes";
      showCommandline({ subgroupOverride: subgroup });
    }
  };

  return (
    <button
      type="button"
      class="textButton"
      aria-label="Shift-click to toggle custom theme"
      data-balloon-pos="left"
      onClick={handleClick}
    >
      <div class="relative">
        <Show when={getThemeIndicator().isFavorite}>
          <div class="absolute top-[-0.5em] right-[-0.5em] flex rounded-full bg-bg p-[0.25em]">
            <Fa icon="fa-star" size={0.5} />
          </div>
        </Show>
        <Fa icon="fa-palette" fixedWidth />
      </div>
      <div class="text">{getThemeIndicator().text}</div>
    </button>
  );
}
