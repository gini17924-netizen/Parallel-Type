import { useQuery } from "@tanstack/solid-query";
import { JSXElement, Show, Suspense } from "solid-js";

import { getServerConfigurationQueryOptions } from "../../../queries/server-configuration";
import { getLoginPageInputsEnabled } from "../../../states/login";
import { LoadingCircle } from "../../common/LoadingCircle";
import { Login } from "./Login";
import { Register } from "./Register";

export function LoginPage(): JSXElement {
  const serverConfig = useQuery(() => getServerConfigurationQueryOptions());
  const isSignUpDisabled = (): boolean =>
    !(serverConfig.data?.users.signUp ?? true);

  return (
    <>
      <Show when={!getLoginPageInputsEnabled()}>
        <div class="fixed top-1/2 left-1/2 z-1 -translate-x-1/2 -translate-y-1/2 text-3xl text-main transition-opacity duration-250">
          <i class="fas fa-fw fa-spin fa-circle-notch"></i>
        </div>
      </Show>
      <Suspense
        fallback={
          <div class="grid h-full content-center">
            <LoadingCircle class="p-4 text-center text-[2rem]" />
          </div>
        }
      >
        <Show
          when={isSignUpDisabled()}
          fallback={
            <div class="flex h-full flex-col items-center justify-around gap-4 md:flex-row">
              <Register />
              <Login />
            </div>
          }
        >
          <div class="grid h-full place-items-center">
            <p>
              Login/Signup is disabled or the server is down/under maintenance.
            </p>
          </div>
        </Show>
      </Suspense>
    </>
  );
}
