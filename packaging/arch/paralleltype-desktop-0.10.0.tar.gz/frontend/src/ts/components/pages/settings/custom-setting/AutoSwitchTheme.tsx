import { ThemeName } from "@monkeytype/schemas/configs";
import { JSXElement, Show } from "solid-js";

import { configMetadata } from "../../../../config/metadata";
import { setConfig } from "../../../../config/setters";
import { getConfig } from "../../../../config/store";
import { ThemesList } from "../../../../constants/themes";
import { cn } from "../../../../utils/cn";
import { Button } from "../../../common/Button";
import SlimSelect from "../../../ui/SlimSelect";
import { SearchableSetting } from "../SearchableSetting";

// built once - a new array on every read would make SlimSelect rebuild its options
const themeOptions = ThemesList.map((theme) => ({
  text: theme.name.replace(/_/g, " "),
  value: theme.name,
}));

export function AutoSwitchTheme(): JSXElement {
  return (
    <SearchableSetting
      key="autoSwitchTheme"
      title={
        configMetadata.autoSwitchTheme.displayString ?? "auto switch theme"
      }
      fa={configMetadata.autoSwitchTheme.fa}
      description={configMetadata.autoSwitchTheme.description}
      inputs={
        <div
          class={cn(
            "grid grid-cols-[repeat(auto-fit,minmax(4.5rem,1fr))] gap-2",
          )}
        >
          <Button
            active={!getConfig.autoSwitchTheme}
            onClick={() => {
              if (!getConfig.autoSwitchTheme) return;
              setConfig("autoSwitchTheme", false);
            }}
            text="off"
          />
          <Button
            active={getConfig.autoSwitchTheme}
            onClick={() => {
              if (getConfig.autoSwitchTheme) return;
              setConfig("autoSwitchTheme", true);
            }}
            text="on"
          />
        </div>
      }
      fullWidthInputs={
        <Show when={getConfig.autoSwitchTheme}>
          <div class="mt-4 grid grid-cols-1 gap-8 md:grid-cols-2">
            <div class="grid grid-cols-[7rem_1fr] items-center gap-2">
              <div>light</div>
              <SlimSelect
                options={themeOptions}
                selected={getConfig.themeLight}
                onChange={(value) =>
                  setConfig("themeLight", value as ThemeName)
                }
              />
            </div>
            <div class="grid grid-cols-[7rem_1fr] items-center gap-2">
              <div>dark</div>
              <SlimSelect
                options={themeOptions}
                selected={getConfig.themeDark}
                onChange={(value) => setConfig("themeDark", value as ThemeName)}
              />
            </div>
          </div>
        </Show>
      }
    />
  );
}
