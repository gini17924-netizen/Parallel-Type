import { JSXElement, createSignal, onMount, onCleanup } from "solid-js";

import { getRoutePage } from "../../../states/router";
import { cn } from "../../../utils/cn";
import { scrollToTop } from "../../../utils/misc";
import { Fa } from "../../common/Fa";

export function ScrollToTop(): JSXElement {
  const [visible, setVisible] = createSignal(false);

  const handleScroll = (): void => {
    if (getRoutePage() === "test") return;

    const scroll = window.scrollY;
    setVisible(scroll > 100);
  };

  onMount(() => {
    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
  });

  onCleanup(() => {
    window.removeEventListener("scroll", handleScroll);
  });

  return (
    <div class="content-grid ScrollToTop pointer-events-none fixed top-0 left-0 z-999999 h-full w-full">
      <button
        class={cn(
          "breakout pointer-events-auto mb-8 grid h-16 w-16 place-self-end rounded-full bg-sub-alt text-[2rem] text-sub ring-8 ring-bg hover:bg-text hover:text-bg",
          {
            "pointer-events-none opacity-0":
              getRoutePage() === "test" || !visible(),
          },
        )}
        style={{
          "grid-column": "content-end/breakout-end",
        }}
        tabIndex="-1"
        type="button"
        onClick={() => {
          setVisible(false);
          scrollToTop();
        }}
      >
        <Fa icon="fa-angle-double-up" />
      </button>
    </div>
  );
}
