import { cleanup, render } from "@solidjs/testing-library";
import { afterEach, describe, expect, it } from "vitest";

import { LoadingPage } from "../../../src/ts/components/pages/LoadingPage";
import {
  planLoadingBar,
  resetLoadingBar,
  runLoadingStep,
} from "../../../src/ts/router/loading-bar";
import { updateLoadingPageBar } from "../../../src/ts/states/loading-page";

/**
 * The fill is animated, so its width lands a frame or two after the step's
 * duration has elapsed. Poll rather than asserting on the next microtask.
 */
async function waitForFillWidth(
  container: HTMLElement,
  expected: string,
): Promise<string | undefined> {
  const deadline = performance.now() + 500;
  let width: string | undefined;
  do {
    width = container.querySelector<HTMLElement>(".bg-main")?.style.width;
    if (width === expected) break;
    await new Promise((resolve) => setTimeout(resolve, 10));
  } while (performance.now() < deadline);
  return width;
}

describe("LoadingPage bar", () => {
  afterEach(() => {
    cleanup();
    resetLoadingBar();
  });

  it("resolves a zero duration step", async () => {
    render(() => <LoadingPage />);
    await expect(updateLoadingPageBar(0, 0)).resolves.toBeUndefined();
  });

  it("fills to the requested percentage", async () => {
    const { container } = render(() => <LoadingPage />);
    await updateLoadingPageBar(42, 50);
    await expect(waitForFillWidth(container, "42%")).resolves.toBe("42%");
  });

  it("lets the newest step win when one supersedes another", async () => {
    const { container } = render(() => <LoadingPage />);
    void updateLoadingPageBar(10, 500);
    await new Promise((resolve) => setTimeout(resolve, 20));
    await updateLoadingPageBar(90, 20);
    await expect(waitForFillWidth(container, "90%")).resolves.toBe("90%");
  });

  // regression: a step used to await the component reporting its animation done,
  // so with nothing mounted to animate it, page loading hung forever
  it("resolves with nothing mounted to animate the fill", async () => {
    await expect(updateLoadingPageBar(10, 0)).resolves.toBeUndefined();
  });

  it("starts the fill at the current step's start when mounted mid-navigation", async () => {
    planLoadingBar(4);
    await runLoadingStep(
      { label: "first", keyframes: [] },
      async () => undefined,
    );
    void runLoadingStep(
      { label: "second", keyframes: [{ percentage: 90, durationMs: 10_000 }] },
      async () => new Promise(() => undefined),
    );
    // the second step's keyframe is under way
    await new Promise((resolve) => setTimeout(resolve, 0));
    // the old page faded out, the loading page mounts while the second runs
    const { container } = render(() => <LoadingPage />);

    expect(container.querySelector<HTMLElement>(".bg-main")?.style.width).toBe(
      "25%",
    );
  });
});
